document.addEventListener('DOMContentLoaded', function () {
    const productFormModal = document.getElementById('productFormModal');
    const editProductFormModal = document.getElementById('editProductFormModal');
    const productForm = document.getElementById('productForm');
    const editProductForm = document.getElementById('editProductForm');
    const closeModal = document.querySelectorAll('.close');
    const productList = document.getElementById('productList');
    const cartList = document.getElementById('cartList'); // Adicionado elemento para a lista do carrinho
    let products = JSON.parse(localStorage.getItem('products')) || [];
    let cartProducts = JSON.parse(localStorage.getItem('cart')) || []; // Lista de produtos no carrinho

    document.getElementById('btnAddProduct').addEventListener('click', function () {
        productFormModal.style.display = 'block';
    });

    closeModal.forEach(btn => {
        btn.addEventListener('click', function () {
            productFormModal.style.display = 'none';
            editProductFormModal.style.display = 'none';
        });
    });

    window.addEventListener('click', function (event) {
        if (event.target === productFormModal) {
            productFormModal.style.display = 'none';
        }
        if (event.target === editProductFormModal) {
            editProductFormModal.style.display = 'none';
        }
    });

    productForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const newProduct = {
            name: productForm.productName.value,
            brand: productForm.productBrand.value,
            description: productForm.productDescription.value,
            price: productForm.productPrice.value,
            ean: productForm.productEAN.value,
            category: productForm.productCategory.value,
            quantity: 0 // Initialize with zero quantity for stock
        };

        products.push(newProduct);
        localStorage.setItem('products', JSON.stringify(products));
        addProductToList(newProduct, products.length - 1);
        productFormModal.style.display = 'none';
        productForm.reset();
        updateStockList();
    });

    editProductForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const index = document.getElementById('editProductIndex').value;
        products[index] = {
            name: editProductForm.editProductName.value,
            brand: editProductForm.editProductBrand.value,
            description: editProductForm.editProductDescription.value,
            price: editProductForm.editProductPrice.value,
            ean: editProductForm.editProductEAN.value,
            category: editProductForm.editProductCategory.value,
            quantity: products[index].quantity // Preserve existing quantity
        };

        localStorage.setItem('products', JSON.stringify(products));
        loadProducts();
        editProductFormModal.style.display = 'none';
        updateStockList();
    });

    function addProductToList(product, index) {
        const productCard = document.createElement('div');
        productCard.className = 'product-card';
        productCard.innerHTML = `
            <h3>${product.name}</h3>
            <p>Marca: ${product.brand}</p>
            <p>Descrição: ${product.description}</p>
            <p>Preço: ${product.price}</p>
            <p>EAN: ${product.ean}</p>
            <p>Categoria: ${product.category}</p>
            <button onclick="editProduct(${index})">Editar</button>
            <button onclick="deleteProduct(${index})">Excluir</button>
            <button onclick="addToCart(${index})">Adicionar ao Carrinho</button>
        `;
        productList.appendChild(productCard);
    }

    function loadProducts() {
        productList.innerHTML = ''; // Clear existing products
        products.forEach((product, index) => addProductToList(product, index));
    }

    window.editProduct = function (index) {
        const product = products[index];
        document.getElementById('editProductIndex').value = index;
        document.getElementById('editProductName').value = product.name;
        document.getElementById('editProductBrand').value = product.brand;
        document.getElementById('editProductDescription').value = product.description;
        document.getElementById('editProductPrice').value = product.price;
        document.getElementById('editProductEAN').value = product.ean;
        document.getElementById('editProductCategory').value = product.category;
        editProductFormModal.style.display = 'block';
    };

    window.deleteProduct = function (index) {
        products.splice(index, 1);
        localStorage.setItem('products', JSON.stringify(products));
        loadProducts();
        updateStockList();
    };

    window.addToCart = function (index) {
        const quantity = prompt("Quantas unidades você deseja adicionar ao carrinho?");
        if (quantity && !isNaN(quantity) && quantity > 0) {
            const product = { ...products[index], quantity: parseInt(quantity, 10) };
            cartProducts.push(product);
            localStorage.setItem('cart', JSON.stringify(cartProducts));
            updateCartList();
            alert("Produto adicionado ao carrinho!");
        } else {
            alert("Quantidade inválida!");
        }
    };

    function updateCartList() {
        cartList.innerHTML = ''; // Clear existing products in the cart
        cartProducts.forEach(product => {
            const cartItem = document.createElement('div');
            cartItem.className = 'cart-item';
            cartItem.innerHTML = `
                <h3>${product.name}</h3>
                <p>Marca: ${product.brand}</p>
                <p>Descrição: ${product.description}</p>
                <p>Preço: ${product.price}</p>
                <p>EAN: ${product.ean}</p>
                <p>Categoria: ${product.category}</p>
                <p>Quantidade: ${product.quantity}</p>
            `;
            cartList.appendChild(cartItem);
        });
    }

    loadProducts();
    updateCartList(); // Ensure cart list is updated on page load
});
