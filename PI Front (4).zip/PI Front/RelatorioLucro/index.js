document.addEventListener("DOMContentLoaded", () => {
    let orders = JSON.parse(localStorage.getItem("orders")) || [];
  
    const calculateTotalSold = () => {
      const totalSold = orders.reduce((acc, order) => {
        acc.totalQuantity += order.quantity;
        acc.totalProfit += order.price * order.quantity;
  
        if (!acc.products[order.name]) {
          acc.products[order.name] = { quantity: 0, profit: 0 };
        }
  
        acc.products[order.name].quantity += order.quantity;
        acc.products[order.name].profit += order.price * order.quantity;
  
        return acc;
      }, {
        totalQuantity: 0,
        totalProfit: 0,
        products: {}
      });
  
      return totalSold;
    };
  
    const displayProfitReport = () => {
      const profitReport = document.getElementById("profitReport");
      const totalSold = calculateTotalSold();
      
      profitReport.innerHTML = "<h2>Relatório de Lucro</h2>";
      
      Object.keys(totalSold.products).forEach((productName) => {
        const product = totalSold.products[productName];
        const productElement = document.createElement("div");
        productElement.className = "product-summary";
        productElement.innerHTML = `
          <h3>${productName}</h3>
          <p>Quantidade Vendida: ${product.quantity}</p>
          <p>Lucro: R$${product.profit.toFixed(2)}</p>
        `;
        profitReport.appendChild(productElement);
      });
  
      const totalElement = document.createElement("div");
      totalElement.className = "total-summary";
      totalElement.innerHTML = `
        <h3>Total Geral</h3>
        <p>Quantidade Total Vendida: ${totalSold.totalQuantity}</p>
        <p>Lucro Total: R$${totalSold.totalProfit.toFixed(2)}</p>
      `;
      profitReport.appendChild(totalElement);
    };
  
    displayProfitReport();
  });
  