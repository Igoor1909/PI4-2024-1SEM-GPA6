document.addEventListener('DOMContentLoaded', function () {
  const stockProductList = document.getElementById('stockProductList');
  const stockProductFormModal = document.getElementById('stockProductFormModal');
  const stockProductForm = document.getElementById('stockProductForm');
  const closeModal = document.querySelector('.close');
  let products = JSON.parse(localStorage.getItem('products')) || [];
  let currentEditingProductIndex = null;

  closeModal.addEventListener('click', function () {
      stockProductFormModal.style.display = 'none';
  });

  window.addEventListener('click', function (event) {
      if (event.target === stockProductFormModal) {
          stockProductFormModal.style.display = 'none';
      }
  });

  stockProductForm.addEventListener('submit', function (event) {
      event.preventDefault();
      if (currentEditingProductIndex !== null) {
          products[currentEditingProductIndex].quantity = stockProductForm.stockProductQuantity.value;
          localStorage.setItem('products', JSON.stringify(products));
          loadStockProducts();
          stockProductFormModal.style.display = 'none';
      }
  });

  function addProductToStockList(product, index) {
      const productCard = document.createElement('div');
      productCard.className = 'product-card';
      productCard.innerHTML = `
          <h3>${product.name}</h3>
          <p>Quantidade em Estoque: ${product.quantity}</p>
          <button onclick="editStockProduct(${index})">Editar Estoque</button>
      `;
      stockProductList.appendChild(productCard);
  }

  function loadStockProducts() {
      stockProductList.innerHTML = ''; // Clear existing products
      products.forEach(addProductToStockList);
  }

  window.editStockProduct = function (index) {
      const product = products[index];
      document.getElementById('stockProductName').value = product.name;
      document.getElementById('stockProductQuantity').value = product.quantity;
      currentEditingProductIndex = index;
      stockProductFormModal.style.display = 'block';
  };

  loadStockProducts();
  window.updateStockList = loadStockProducts; // Make function accessible globally
});
