document.addEventListener("DOMContentLoaded", () => {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  let orders = JSON.parse(localStorage.getItem("orders")) || [];

  const saveOrders = () => {
    localStorage.setItem("orders", JSON.stringify(orders));
  };

  const saveCart = () => {
    localStorage.setItem("cart", JSON.stringify(cart));
  };

  const displayCart = () => {
    const cartList = document.getElementById("cartList");
    cartList.innerHTML = "";
    cart.forEach((item) => {
      const cartItem = document.createElement("div");
      cartItem.className = "product-card";
      cartItem.innerHTML = `
        <h3>${item.name}</h3>
        <p>Marca: ${item.brand}</h3>
        <p>Descrição: ${item.description}</p>
        <p>Preço: R$${item.price}</p>
        <p>EAN: ${item.ean}</p>
        <p>Categoria: ${item.category}</p>
        <p>Quantidade: ${item.quantity}</p>
      `;
      cartList.appendChild(cartItem);
    });
  };

  const checkoutCart = () => {
    if (cart.length > 0) {
      orders = [...orders, ...cart];
      cart = [];
      saveOrders();
      saveCart();
      alert("Compra finalizada com sucesso!");
      displayCart();
      window.location.href = "/PedidosSolicitados/index.html"; // Redireciona para a página de pedidos solicitados
    } else {
      alert("Carrinho está vazio!");
    }
  };

  document.getElementById("btnCheckout").onclick = checkoutCart;
  displayCart();
});
