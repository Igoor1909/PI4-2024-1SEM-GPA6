document.addEventListener("DOMContentLoaded", () => {
    let orders = JSON.parse(localStorage.getItem("orders")) || [];
  
    const displayOrders = () => {
      const orderList = document.getElementById("orderList");
      orderList.innerHTML = "";
      orders.forEach((item) => {
        const orderItem = document.createElement("div");
        orderItem.className = "product-card";
        orderItem.innerHTML = `
          <h3>${item.name}</h3>
          <p>Marca: ${item.brand}</p>
          <p>Descrição: ${item.description}</p>
          <p>Preço: R$${item.price}</p>
          <p>EAN: ${item.ean}</p>
          <p>Quantidade: ${item.quantity}</p>
        `;
        orderList.appendChild(orderItem);
      });
    };
  
    displayOrders();
  });
  