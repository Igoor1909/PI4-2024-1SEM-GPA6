package com.example.B2BSmart.exceptions;

public class StatusEnviadoException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public StatusEnviadoException(String message) {
		super(message);
	}
 
	
	
}
