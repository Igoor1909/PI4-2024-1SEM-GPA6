package com.example.B2BSmart.exceptions;

public class EanExistException extends Exception {

	public EanExistException(String message) {
		super(message);
	}

	private static final long serialVersionUID = 1L;
	
}
