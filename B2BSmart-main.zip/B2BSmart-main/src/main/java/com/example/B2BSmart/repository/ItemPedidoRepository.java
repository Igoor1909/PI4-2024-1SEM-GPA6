package com.example.B2BSmart.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.B2BSmart.entity.ItemPedido;

public interface ItemPedidoRepository extends JpaRepository<ItemPedido, Long> {
	
    
}


