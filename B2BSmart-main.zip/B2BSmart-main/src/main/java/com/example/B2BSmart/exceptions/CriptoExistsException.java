package com.example.B2BSmart.exceptions;

public class CriptoExistsException extends Exception {

	public CriptoExistsException(String message) {
		super(message);
		
	}
	
	private static final long serialVersionUID = 1L;

	
}
