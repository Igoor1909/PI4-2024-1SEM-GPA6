package com.example.B2BSmart.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.B2BSmart.entity.Categoria;

public interface CategoriaRespository extends JpaRepository<Categoria, Long> {


}

