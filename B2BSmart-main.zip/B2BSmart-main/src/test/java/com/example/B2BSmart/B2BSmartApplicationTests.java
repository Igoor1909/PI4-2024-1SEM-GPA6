package com.example.B2BSmart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class B2BSmartApplicationTests {

	@Test
	void contextLoads() {
	}

}
