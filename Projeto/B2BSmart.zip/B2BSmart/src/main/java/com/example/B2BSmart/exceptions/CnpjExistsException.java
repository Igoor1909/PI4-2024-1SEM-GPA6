package com.example.B2BSmart.exceptions;

public class CnpjExistsException extends Exception {

	public CnpjExistsException(String message) {
		super(message);
	}

	private static final long serialVersionUID = 1L;

	
}
