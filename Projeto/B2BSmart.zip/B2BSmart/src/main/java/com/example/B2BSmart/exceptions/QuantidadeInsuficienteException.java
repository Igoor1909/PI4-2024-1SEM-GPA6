package com.example.B2BSmart.exceptions;

public class QuantidadeInsuficienteException extends Exception {

	
	
	public QuantidadeInsuficienteException(String message) {
		super(message);
		
	}

	private static final long serialVersionUID = 1L;

}
